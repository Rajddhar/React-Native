import React, {PureComponent, Component} from 'react';
import {
    View,
    Text,
    TouchableHighlight,
    StyleSheet,
    Image
} from 'react-native';
import {imageUri, imageUriForCached} from "../../../helpers/UtilityFunctions";
import PropTypes from 'prop-types';
import * as _ from 'lodash';
//import FastImage from 'react-native-fast-image'
import {FastImg} from "../../FastImage";

const propTypes = {
  column: PropTypes.number,
  contact: PropTypes.object,
  row: PropTypes.number,
  toggleInvite: PropTypes.func
};

export default class ContactItem extends Component{
    constructor(props){
        super(props);

    }

    shouldComponentUpdate(nextProps){
        return compareProp(nextProps.contact, this.props.contact);
    }

    render(){
        return (
            <View key={this.props.column} style={[styles.columnContainer,{marginRight: (this.props.column==0||this.props.column==1)?5:0}]}>
                <View style={{flex:0.5}}>
                    <FastImg source={imageUriForCached(this.props.contact.thumbnail)} style={styles.thumbnail} />
                </View>
                <View style={{flex:0.1, flexDirection: 'row', alignItems: 'flex-start'}}>
                    <Text style={styles.name}>{_.capitalize(this.props.contact.name)}</Text>
                </View>
                <View
                    style={styles.buttonView}
                >
                    <TouchableHighlight
                        onPress={this.props.toggleInvite.bind(this,this.props.contact,this.props.row, this.props.column)}
                        underlayColor={'transparent'}
                        style={[styles.buttonContainer,{backgroundColor: this.props.contact.invited || this.props.contact.invite ? '#fff' : 'transparent'}]}
                        disabled={this.props.contact.invited}

                    >
                        <Text style={[styles.buttonText, {color: this.props.contact.invited || this.props.contact.invite ? '#AC0E05' : '#fff'}]}>
                            {this.props.contact.invited ? 'Invited' : 'Invite'}
                        </Text>
                    </TouchableHighlight>
                </View>
            </View>
        )
        
    }
}


function compareProp(nextContact, contact){
    return (
        (nextContact.invite !== contact.invite)
        ||
        (nextContact.invited !== contact.invited)
        ||
        nextContact.thumbnail !== contact.thumbnail
        ||
        !_.isEqual(nextContact.phone.sort(), contact.phone.sort())
    )
}


ContactItem.propTypes = propTypes;


const styles = StyleSheet.create({
    text: {
        fontSize: 25,
        fontWeight: 'bold',
        color: "#FFF",
        textAlign: 'center',
    },
    name: {
        color: '#fff',
        paddingLeft:2,
        paddingRight: 2
    },
    thumbnail:{
        height:90,
        width:90,
        borderRadius: 6
    },
    columnContainer: {
        flex: 1,
        flexDirection:'column',
        backgroundColor: '#960117',
        marginBottom: 5,
        borderRadius: 6,
        paddingTop:2,
        paddingBottom: 2,
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonView:{
        flex: 0.4,
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
        marginRight: 5,
        paddingTop: 2,
        paddingBottom: 2
    },
    buttonContainer:{
        flex: 1, flexDirection: 'column',
        borderColor: 'rgba(255,255,255,0.7)',
        borderWidth: 1,
        borderRadius: 15, alignItems: 'center',
        justifyContent: 'center', paddingLeft: 5, paddingRight: 5,
        paddingTop: 5, paddingBottom: 5,
        marginLeft: 15, marginRight: 15
    },
    buttonText:{
        color: '#fff',
        fontSize: 10,
        alignItems: 'center',
        justifyContent: 'center'
    },
})