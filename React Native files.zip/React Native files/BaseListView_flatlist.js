import React, {Component} from 'react'
import {connect} from 'react-redux'
import {
  RefreshControl,
  View,
  TouchableOpacity,
  TextInput,
  Text,
  TabBarIOS,
  StyleSheet,
  ScrollView,
  ListView,
  FlatList,
  StatusBar,
  Image,
  RecyclerViewBackedScrollView,
  TouchableHighlight,
  TouchableWithoutFeedback,
  ImageBackground,
  Dimensions,
  Platform
} from 'react-native'
import PropTypes from 'prop-types';
// custom
import {reverse} from 'lodash';
import I18n from 'react-native-i18n';
import Styles from './Styles/BaseListViewStyle';
import {Images, Colors, Metrics} from './Themes';
import {debounce, findKey} from 'lodash';
import * as Animatable from 'react-native-animatable';

const deviceWidth = Dimensions.get('window').width;




class BaseListView extends Component {

  // ------------ init -------------

  constructor(props) {
    super(props);

    const ds = new ListView.DataSource({
      rowHasChanged: (r1, r2) => r1 !== r2,
      sectionHeaderHasChanged: (s1, s2) => s1 !== s2
    });

    const {data = [], search} =  this.props;

    this.state = {
      isRefreshing: false,
      ds,
      dataSource: ds.cloneWithRowsAndSections(data),
      value: '',
      height: 34,
      focused: false,
      visibleHeight: Metrics.screenHeight,
      isEmoji: false,
      ind: 0
    }
  }

  // ------------ logic  ---------------

  updateList(props) {
    //TODO: compare prev and next, search sorting
    const {data = [], search} = props || this.props;
    this.setState({
      dataSource: this.state.ds.cloneWithRowsAndSections(data)
    })
  }

  // ------------ lifecycle ------------

  componentDidMount() {
    // this.updateList()
  }

  componentWillReceiveProps(nextProps) {
      // console.log(nextProps.data);
    this.updateList(nextProps)
  }

  componentDidUpdate() {
    const {autoScroll} = this.props;

    if (autoScroll && "listHeight" in this.state &&
      "footerY" in this.state &&
      this.state.footerY > this.state.listHeight) {
      let scrollDistance = this.state.listHeight - this.state.footerY;
      this.refs.list.getScrollResponder().scrollTo({y: -scrollDistance, animated: true});
    }
  }

  // ------------ handlers -------------

  handleRefresh() {
    const {handleRefresh} = this.props;

    this.setState({isRefreshing: true});
    handleRefresh();
    // TODO: refresh succeed/failed
    setTimeout(() => {
      this.setState({isRefreshing: false})
    }, 1000)
  }


  // ------------ renders -------------

  _renderRow(rowData, sectionId, rowID, highlightRow) {
    return (
      <TouchableOpacity onPress={() => {
        {/*NavigationActions.contactInfo({"uid": rowData})*/
        }
      }}>
        <View style={Styles.row}>
          <Image source={Images.default} resizeMode='cover' style={Styles.rowLogo}/>
          <View style={Styles.rowName}>
            <Text>{rowData}</Text>
          </View>
        </View>
      </TouchableOpacity>
    )
  }


  _renderSeparator(sectionID, rowID, adjacentRowHighlighted) {
    return (
      <View
        key={`${sectionID}-${rowID}`}
        style={Styles.separator}
      />
    )
  }



  onPressSend() {
      this.props.handleSend();
  }

    handleEmojiCancel() {
        if (!this.state.value) return
        const arr = this.state.value.split('')
        const len = arr.length
        let newValue = ''

        if (arr[len - 1] != ']') {
            arr.pop()
            newValue = arr.join('')
        } else {
            const index = arr.lastIndexOf('[')
            newValue = arr.splice(0, index).join('')
        }

        this.setState({
            value: newValue
        })
    }


  _renderMessageBar() {
      const {value = '', isEmoji} = this.state;

      return (
          <View style={{flex: 1, flexDirection: 'column'}}>
              <View style={Styles.inputRow}>
                  <View style={Styles.searchRow}>
                      <TextInput
                          ref="search"
                          // style={[Styles.searchInput, {height: Math.min(Math.max(this.props.height, 34), 100)}]}
                          style={Styles.searchInput}
                          value={this.props.text}
                          editable={true}
                          keyboardType='default'
                          returnKeyType='default'
                          autoCapitalize='none'
                          autoCorrect={true}
                          multiline={true}
                          onFocus={this.props.handleFocusSearch.bind(this)}
                          onBlur={this.props.handleBlurSearch.bind(this)}
                          onChangeText={this.handleChangeText.bind(this)}
                          onEndEditing={() => {
                          }}
                          onLayout={() => {
                          }}
                          underlineColorAndroid='transparent'
                          onSubmitEditing={() => this.refs.search.focus()}
                          placeholder={I18n.t('sendMessage')}
                          placeholderTextColor={'white'}
                      />
                  </View>

                  <TouchableOpacity
                    style={Styles.searchExtra}
                    onPress={() => {this.onPressSend(this.state.value)}}
                  >
                    <ImageBackground
                      style={{width: 34, height: 34}}
                      source={require('../../assets/GamePlay/yy_ic_gameplay_icon_sendChat.png')}
                    />
                  </TouchableOpacity>
                </View>


              </View>
      )
  }





  handleChangeText(v) {

      this.props.handleChangeText(v);
  }


  render() {
    const {hasNav, renderRow, renderSeparator, listViewStyle, autoScroll = false} = this.props

    const containerStyle = [Styles.container]
    // hasNav && containerStyle.push({marginTop: Metrics.navBarHeight})
    const listStyle = [Styles.listView]
    listViewStyle && listStyle.push(listViewStyle)

    let component = null;
    if (this.props.currentState === 'question') {
      component = <View
                    style={{
                      flex: 10,
                      flexDirection: 'column',
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <Animatable.Text
                      ref="text"
                      style={{
                        fontSize: 25,
                        fontWeight: 'bold',
                        color: '#FFF',
                        textAlign: 'left',
                        backgroundColor: 'rgba(52, 52, 52, 0)',
                        lineHeight: 26
                      }}
                    >
                      {this.props.questionText}
                    </Animatable.Text>
                  </View>;
    // } else if (this.props.currentState === 'answer') {
    } else {
        // this.refs.text.transitionTo({fontSize: 15, lineHeight: 15});
        component = <View style={{flex: 10}}>
            <View
                style={{
                    // flex: 1.5,
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                }}
            >
                <Animatable.Text
                    ref="text"
                    style={{
                        fontSize: 15,
                        fontWeight: 'bold',
                        color: '#FFF',
                        textAlign: 'left',
                        backgroundColor: 'rgba(52, 52, 52, 0)',
                        lineHeight: 15
                    }}
                    animation="bounceIn"
                    duration={2000}
                >
                    {this.props.questionText}
                </Animatable.Text>
            </View>
            {/* ------------------------- ANSWER ------------------------- */}
            <View style={{flex: 10}}>
                <FlatList
                    ref="list"
                    refreshControl={
                        <RefreshControl
                            refreshing={this.state.isRefreshing}
                            onRefresh={this.handleRefresh.bind(this)}
                            title="Loading..."
                            titleColor="white"
                        />
                    }
                    automaticallyAdjustContentInsets={false}
                    initialListSize={10}
                    enableEmptySections={true}
                    style={listStyle}
                    data={this.props.data ? reverse([...this.props.data]) : []}//dataSource={this.state.dataSource}
                    //renderItem={renderRow || this._renderRow.bind(this)}
                    renderItem={renderRow}//renderRow={renderRow || this._renderRow.bind(this)}
                    renderSeparator={renderSeparator || this._renderSeparator.bind(this)}
                    //renderScrollComponent={props => <RecyclerViewBackedScrollView {...props} />}
                    inverted
                    onLayout={(event) => {
                        this.setState({
                            listHeight: event.nativeEvent.layout.height
                        })
                    }}
                    renderFooter={() => {
                        return (<View onLayout={(event) => {
                            this.setState({
                                footerY: event.nativeEvent.layout.y
                            })
                        }}/>)
                    }}
                    
                />
            </View>
        </View>;
    }

    return (
      <View style={{flex: 1}}>
        {/* ------------------------- COMPONENT ------------------------- */}
        {component}
        {/* ------------------------- MESSAGE BAR ------------------------- */}
        <View style={{flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingTop: 20}}>
          {this._renderMessageBar()}
        </View>
      </View>
    )
  }
}

BaseListView.propTypes = {
  hasNav: PropTypes.bool,
  data: PropTypes.array,
  search: PropTypes.string,
  handleRefresh: PropTypes.func,
  renderRow: PropTypes.func,
  renderSeparator: PropTypes.func,
  handleFocusSearch: PropTypes.func,
  handleBlurSearch: PropTypes.func,
  handleChangeText: PropTypes.func,
  handleSend: PropTypes.func,
  height: PropTypes.number,
  currentState: PropTypes.string,
  questionText: PropTypes.string,
  text: PropTypes.string
}

export default BaseListView
