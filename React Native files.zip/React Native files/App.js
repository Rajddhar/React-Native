/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {Linking, AppState, Platform} from 'react-native';
import {Provider} from 'react-redux';
import CreateStore from './constants/CreateStore';
import {Router} from './Router';
import {ChatOpen} from './services/ChatConnection';
import './I18n/I18n';
import PushNotification  from 'react-native-push-notification';
import { MenuProvider } from 'react-native-popup-menu';
import {ADD_EMAIL_ID_FOR_APPROVED_USER, ADD_TOKEN_FROM_DEEP_LINK, ON_DEVICE_TOKEN_REGISTER} from "./actions/types";
import { withNetworkConnectivity } from 'react-native-offline';
import {Validations} from "./constants/Validations";
import timer from 'react-native-timer';
export const store = CreateStore();

// ChatListener(store);



PushNotification.configure({

    // (optional) Called when Token is generated (iOS and Android)
    onRegister: function(token) {
        store.dispatch({type: ON_DEVICE_TOKEN_REGISTER, token: token.token});

    },
    // (required) Called when a remote or local notification is opened or received
    onNotification: function(notification) {
        console.log( 'NOTIFICATION:', notification );
    },

    // ANDROID ONLY: GCM Sender ID (optional - not required for local notifications, but is need to receive remote push notifications)
    senderID: "520374969337",

    // IOS ONLY (optional): default: all - Permissions to register.
    permissions: {
        alert: true,
        badge: true,
        sound: true
    },

    // Should the initial notification be popped automatically
    // default: true
    popInitialNotification: true,

    /**
     * (optional) default: true
     * - Specified if permissions (ios) and token (android and ios) will requested or not,
     * - if not, you must call PushNotificationsHandler.requestPermissions() later
     */
    requestPermissions: true,
});



const RouterWithNetworkStatus = withNetworkConnectivity({
    withRedux: true, // It won't inject isConnected as a prop in this case
    checkConnectionInterval: 6000,
})(Router);

export default class App extends Component{
    constructor() {
        super();
        this.state= {appState: 'background'};
        // this.ChatEngine = store.getState().webim.ChatEngine;
        // console.log('CCCC asd ', this.ChatEngine);
        // store.dispatch(LoginActions.login('apple', 'apple'));    // example account
        // const store  = CreateStore();

    }

    componentDidMount(){
        AppState.addEventListener('change', this._handleAppStateChange);
        Linking.addEventListener('url', this.handleUrl);
    }

    componentWillUnmount(){
        AppState.removeEventListener('change', this._handleAppStateChange);
        Linking.removeEventListener('url');
        // timer.clearInterval('lastSeen');
    }

    _handleAppStateChange = (nextAppState) => {
        const {ChatEngine, me} = store.getState().webim;
        if (this.state.appState.match(/inactive|background/) && nextAppState === 'active') {
           if(ChatEngine.ready) {
               // me.update({
               //     online: true,
               //
               // });
               me.update({appState: 'foreground'})
           }
            // console.log('App has come to the foreground!')
        }
        else{
            if(ChatEngine.ready) {
                // me.update({
                //     online: false,
                // });
                me.update({appState: 'background'})
            }
        }
        this.setState({appState: nextAppState});
    }

    handleUrl(event){
        if(Platform.OS === 'ios') {
            lookup = 'yadayada://';
            if (event.url && event.url.indexOf(lookup) === 0) {
                const email = event.url.slice(lookup.length);
                if (Validations.EMAIL_VALIDATION.test(email)) {
                    store.dispatch({type: ADD_EMAIL_ID_FOR_APPROVED_USER, email})
                }
                // if(token.length > 0){
                //     store.dispatch({type: ADD_TOKEN_FROM_DEEP_LINK, token});
                // }
            }
        }

        console.log(event.url);
    };




  render(){
    return(
      <Provider store={store} >
        <MenuProvider>
         <RouterWithNetworkStatus/>
        </MenuProvider>
      </Provider>
    )
  }
}


