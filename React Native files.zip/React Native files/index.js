import React, {Component} from 'react';
import {View} from 'react-native';
import PropTypes from 'prop-types';
import {Answer} from "./Answer";
import {WildCardAnswer} from "./WildCardAnswer";
import {Chat} from './Chat';
import {BotRow} from "./BotRow";

const propTypes = {
    bySelf: PropTypes.bool,
    //message sent by this user or not

    data: PropTypes.object,
    //message data object

    userThumbnail: PropTypes.string,
    //this user's thumbnail url

    partnerThumbnail: PropTypes.string,
    //partner's thumbnail url

    currentQuestionIndex: PropTypes.number,
    //current question index (card index)

    cardType:PropTypes.string,
    //cardType 'normal'/'wildcard'

    allOptions: PropTypes.array,
    //all options for a wild card answer

    from: PropTypes.string
    //message sent by....
};

export default class GameRow extends Component{

    constructor(props){
        super(props);
    }

    shouldComponentUpdate(nextProps){
        return (nextProps.data.msg !== this.props.data.msg);
    }

    render(){
        let component = null;
        /*
          if row has a key questionIndex only then it should be shown in the ui:
             if it is from bot --> render as bot
             else if it is of type 'ANS' --> render as answer (wildcard/normal)
             else if it is of type 'CHAT' ---> render as chat
        * */
        if(this.props.currentQuestionIndex == this.props.data.questionIndex){
            if(this.props.from === 'bot'){
                component = <BotRow {...mapProps(this.props)}/>
            }
           else if(this.props.data.type === 'ANS'){
               if(this.props.cardType == 'wildcard'){
                   component = <WildCardAnswer {...mapProps(this.props)}  allOptions={this.props.allOptions} />
               }
               else{
                   component = <Answer {...mapProps(this.props)} />
               }
           }
           else if(this.props.data.type === 'CHAT'){
               component = <Chat {...mapProps(this.props)} />
           }
        }
        return (<View>{component}</View>);
    }
}

/* map common props to the row components */
function mapProps(props){
    return {
        partnerThumbnail: props.partnerThumbnail,
        userThumbnail: props.userThumbnail,
        data: props.data,
        bySelf: props.bySelf
    }
}


GameRow.propTypes = propTypes;