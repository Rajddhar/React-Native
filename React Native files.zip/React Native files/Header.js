import React from 'react';
import {View, TouchableHighlight, Image, Text, StyleSheet} from 'react-native';
import PropTypes from 'prop-types';
import {verticalScale} from '../helpers/scale';
import Icon from 'react-native-vector-icons/Ionicons';
import FastImage from 'react-native-fast-image';

const propTypes = {
    leftPress: PropTypes.func,
    rightPress: PropTypes.func,
    // leftIcon: Image.propTypes.source,
    // rightIcon: Image.propTypes.source,
    // leftIconStyle: View.propTypes.style,
    // rightIconStyle: View.propTypes.style,
    title: PropTypes.string,
    backgroundColor: PropTypes.string,
    titleColor: PropTypes.string,
    leftIconName: PropTypes.string,
    onLayout: PropTypes.func
};

const iconStyle = {
    width: 32,
    height: 32,
};
const defaultProps = {
    leftIconStyle:  iconStyle,
    rightIconStyle: iconStyle,
    backgroundColor:'#A41312',
    titleColor: '#fff',
    leftIconName: ''
}

const Header = ({leftPress, rightPress, leftIcon, rightIcon, title, leftIconStyle, rightIconStyle, backgroundColor, titleColor, leftIconName, onLayout}) => {
    return (
        <View style={[styles.header, {backgroundColor}]} onLayout={onLayout}>
            <View style={styles.wrapper}>
                {
                    (leftIconName.length > 0) &&
                    <Icon name={leftIconName} size={40} color={'#DFCAAB'} backgroundColor="transparent" onPress={leftPress}/>
                    ||
                    <TouchableHighlight
                        onPress={leftPress}
                        underlayColor={'transparent'}
                    >
                        <FastImage
                            style={leftIconStyle}
                            source={leftIcon}
                        />
                    </TouchableHighlight>
                }


            </View>
            <View style={styles.titleWrapper}>
                <Text style={[styles.title, {color:titleColor} ]}>{title}</Text>
            </View>
            <View style={styles.wrapper}>
                <TouchableHighlight
                    onPress={rightPress}
                    underlayColor={'transparent'}
                >
                    <Image
                        style={rightIconStyle}
                        source={rightIcon}
                    />
                </TouchableHighlight>
            </View>
        </View>
    )
};

Header.propTypes = propTypes;
Header.defaultProps = defaultProps;


const styles = StyleSheet.create({
    header: {
        // backgroundColor:'#A41312',
        flexDirection:'row',
        justifyContent: 'space-between',
        height: verticalScale(55),
    },
    wrapper: {
        marginLeft: verticalScale(10),
        marginRight: verticalScale(10),
        justifyContent: 'center',
    },
    titleWrapper: {
        justifyContent: 'center',
    },
    title: {
        fontSize: 15,
        color: "#FFF",
    },
    close: {
        width: 32,
        height: 32,
    },
})

export {Header}